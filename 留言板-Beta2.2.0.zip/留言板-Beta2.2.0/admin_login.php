<?php
session_start();

// 检查是否已登录
if (isset($_SESSION['admin']) && $_SESSION['admin'] === true) {
    header('Location: adminly.php');
    exit;
}

// 处理登录请求
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $password = $_POST['password'];

    // 检查密码，改密码看这里
    if ($password === '12345abc') {
        $_SESSION['admin'] = true;
        header('Location: adminly.php');
        exit;
    } else {
        $errorMessage = '密码错误。';
    }
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>管理员登录</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f0f8ff;
            color: #333;
            max-width: 600px;
            margin: 0 auto;
            padding: 20px;
            font-family: Arial, sans-serif;
        }
        .form-container {
            background-color: #e3f2fd;
            padding: 20px;
            border-radius: 16px;
            margin-top: 32px;
            color: #333;
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.1);
        }
        .form-container input,
        .form-container button {
            width: 100%;
            margin-bottom: 16px;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 16px;
            box-sizing: border-box;
            outline: none;
        }
        .form-container input:focus,
        .form-container button:focus {
            outline: none;
            box-shadow: 0 0 5px rgba(0, 123, 255, 0.5);
        }
        .form-container button {
            background-color: #007bff;
            color: #fff;
            cursor: pointer;
            transition: background-color 0.3s;
        }
        .form-container button:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <div class="container mx-auto p-6">
        <h1 class="text-3xl font-bold text-center text-blue-600 mb-6">管理员登录</h1>

        <div class="form-container">
            <form method="post">
                <input type="password" name="password" placeholder="管理员密码" required>
                <button type="submit">登录</button>
            </form>
            <?php if (isset($errorMessage)): ?>
                <p class="text-center text-red-500 mt-4"><?= htmlspecialchars($errorMessage) ?></p>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>
