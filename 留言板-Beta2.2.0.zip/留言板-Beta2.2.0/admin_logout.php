<?php
session_start();

// 清除管理员会话
unset($_SESSION['admin']);
session_destroy();

// 重定向到管理员登录页面
header('Location: admin_login.php');
exit;
?>
