<?php
session_start();

$messagesFile = 'messages.json';
$ipLimitsFile = 'ip_limits.json';

// 检查管理员登录状态
if (!isset($_SESSION['admin']) || $_SESSION['admin'] !== true) {
    header('Location: admin_login.php');
    exit;
}

// 读取现有留言
$messages = [];
if (file_exists($messagesFile)) {
    $messages = json_decode(file_get_contents($messagesFile), true);
}

// 读取IP限制记录
$ipLimits = [];
if (file_exists($ipLimitsFile)) {
    $ipLimits = json_decode(file_get_contents($ipLimitsFile), true);
}

// 处理表单提交
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['delete'])) {
        // 删除留言
        $deleteId = $_POST['delete'];
        foreach ($messages as $index => $msg) {
            if ($msg['id'] == $deleteId) {
                unset($messages[$index]);
                $messages = array_values($messages); // 重建数组索引
                file_put_contents($messagesFile, json_encode($messages));
                break;
            }
        }
        header('Location: adminly.php');
        exit;
    } else {
        // 添加留言
        $qq = $_POST['qq'];
        $nickname = $_POST['nickname'];
        $message = $_POST['message'];
        //判断是否有x-real ip
        
        $ip = getClientIp();

        // 添加留言
        $messages[] = [
            'id' => uniqid(), // 生成唯一ID
            'qq' => $qq,
            'nickname' => $nickname,
            'message' => $message,
            'ip' => $ip
        ];
        file_put_contents($messagesFile, json_encode($messages));

        // 更新IP限制记录（管理员不受时间限制）
        $ipLimits[$ip] = time();
        file_put_contents($ipLimitsFile, json_encode($ipLimits));

        // 重定向到当前页面，避免表单重复提交
        header('Location: adminly.php');
        exit;
    }
}

function getMessageImageUrl($qq) {
    return "http://q1.qlogo.cn/g?b=qq&nk=$qq&s=100";
}
function getClientIp() {
    // 首先检查 Cloudflare 特定的头部
    if (!empty($_SERVER['HTTP_CF_CONNECTING_IP'])) {
        $ip = $_SERVER['HTTP_CF_CONNECTING_IP'];
    }
    // 检查常见的代理头部
    elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
    }
    // 其他可能包含真实 IP 的头部
    elseif (!empty($_SERVER['HTTP_X_REAL_IP'])) {
        $ip = $_SERVER['HTTP_X_REAL_IP'];
    }
    // 默认使用 REMOTE_ADDR
    else {
        $ip = $_SERVER['REMOTE_ADDR'];
    }

    // 处理可能存在的 IP 地址列表（以逗号分隔）
    $ipList = explode(',', $ip);
    return trim($ipList[0]);
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>留言板后台</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f0f8ff;
            color: #333;
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
            font-family: Arial, sans-serif;
        }
        .message-card {
            border: 1px solid #007bff;
            border-radius: 16px;
            padding: 16px;
            margin-bottom: 16px;
            display: flex;
            align-items: center;
            background-color: #007bff;
            color: #fff;
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.1);
            position: relative;
            max-width: 100%;
            box-sizing: border-box;
        }
        .message-card img {
            border-radius: 50%;
            margin-right: 16px;
            width: 50px;
            height: 50px;
        }
        .message-card .content {
            flex: 1;
        }
        .message-card .delete-button {
            position: absolute;
            top: 10px;
            right: 10px;
            background: none;
            border: none;
            color: #b0b0b0; /* 初始灰色 */
            cursor: pointer;
            font-size: 16px; /* 较小的字体大小 */
            transition: color 0.3s;
        }
        .message-card .delete-button:hover {
            color: #808080; /* 悬停时深灰色 */
        }
        .form-container {
            background-color: #e3f2fd;
            padding: 20px;
            border-radius: 16px;
            margin-top: 32px;
            color: #333;
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.1);
        }
        .form-container input,
        .form-container textarea,
        .form-container button {
            width: 100%;
            margin-bottom: 16px;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 16px;
            box-sizing: border-box;
            outline: none;
        }
        .form-container input:focus,
        .form-container textarea:focus,
        .form-container button:focus {
            outline: none;
            box-shadow: 0 0 5px rgba(0, 123, 255, 0.5);
        }
        .form-container button {
            background-color: #007bff;
            color: #fff;
            cursor: pointer;
            transition: background-color 0.3s;
        }
        .form-container button:hover {
            background-color: #0056b3;
        }
        .logout-button {
            font-size: 14px; /* 较小的字体大小 */
            background-color: #007bff;
            color: #fff;
            border: none;
            padding: 5px 10px;
            border-radius: 12px;
            cursor: pointer;
            transition: background-color 0.3s;
        }
        .logout-button:hover {
            background-color: #0056b3;
        }
        .ip-address {
            color: #d1d5db; /* Light gray color */
            font-size: 14px;
            margin-top: 8px;
        }
    </style>
</head>
<body>

    <div class="container mx-auto p-6">
        <div class="flex items-center justify-center mb-6">
            <h1 class="text-3xl font-bold text-center text-blue-600 flex-grow">留言板后台</h1>
            <form method="post" action="admin_logout.php">
                <button type="submit" class="logout-button ml-4">登出</button>
            </form>
        </div>

        <div id="messages" class="grid grid-cols-1 sm:grid-cols-3 lg:grid-cols-3 gap-4">
            <?php foreach ($messages as $index => $msg): ?>
                <div class="message-card">
                    <img src="<?= getMessageImageUrl($msg['qq']) ?>" alt="Avatar">
                    <div class="content">
                        <strong><?= htmlspecialchars($msg['nickname']) ?></strong>
                        <p><?= htmlspecialchars($msg['message']) ?></p>
                        <p class="ip-address">IP: <?= htmlspecialchars($msg['ip']) ?></p>
                    </div>
                    <form method="post" style="display: inline;">
                        <button type="submit" name="delete" value="<?= htmlspecialchars($msg['id']) ?>" class="delete-button">✖</button>
                    </form>
                </div>
            <?php endforeach; ?>
        </div>

        <div class="form-container">
            <form method="post">
                <input type="text" name="qq" placeholder="QQ号" required>
                <input type="text" name="nickname" placeholder="昵称" required>
                <textarea name="message" rows="4" placeholder="输入留言内容" required></textarea>
                <button type="submit">添加留言</button>
            </form>
        </div>
    </div>

</body>
</html>
