<?php
/*
By-QQ-3220257676
Fuxsto
*/
session_start();
$messages = [];
$messagesFile = 'messages.json';
$ipLimitsFile = 'ip_limits.json';

// 读取现有留言
if (file_exists($messagesFile)) {
    $messages = json_decode(file_get_contents($messagesFile), true);
}

// 读取IP限制记录
$ipLimits = [];
if (file_exists($ipLimitsFile)) {
    $ipLimits = json_decode(file_get_contents($ipLimitsFile), true);
}

// 处理表单提交
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['delete'])) {
        // 删除留言
        $deleteId = $_POST['delete'];
        $ip = $_SERVER['REMOTE_ADDR'];

        // 确保要删除的留言属于当前IP
        foreach ($messages as $index => $msg) {
            if ($msg['id'] == $deleteId && $msg['ip'] == $ip) {
                unset($messages[$index]);
                $messages = array_values($messages); // 重建数组索引
                file_put_contents($messagesFile, json_encode($messages));
                break;
            }
        }
        header('Location: ' . $_SERVER['PHP_SELF']);
        exit;
    } else {
        // 添加留言
        $qq = htmlspecialchars($_POST['qq']);
        $nickname = $_POST['nickname'];
        $message = $_POST['message'];
        $ip = $_SERVER['REMOTE_ADDR'];

        // 检查IP是否在限制时间内
        $currentTime = time();
        if (isset($ipLimits[$ip])) {
            $lastCommentTime = $ipLimits[$ip];
            if (($currentTime - $lastCommentTime) < 600) { // 10分钟 = 600秒
                $errorMessage = "每个IP每10分钟只能留言一次。";
            } else {
                // 更新IP限制记录
                $ipLimits[$ip] = $currentTime;
                file_put_contents($ipLimitsFile, json_encode($ipLimits));

                // 添加留言
                $messages[] = [
                    'id' => uniqid(), // 生成唯一ID
                    'qq' => $qq,
                    'nickname' => $nickname,
                    'message' => $message,
                    'ip' => $ip
                ];
                file_put_contents($messagesFile, json_encode($messages));

                // 重定向到当前页面，避免表单重复提交
                header('Location: ' . $_SERVER['PHP_SELF']);
                exit;
            }
        } else {
            // 新IP，添加留言
            $ipLimits[$ip] = $currentTime;
            file_put_contents($ipLimitsFile, json_encode($ipLimits));

            $messages[] = [
                'id' => uniqid(), // 生成唯一ID
                'qq' => $qq,
                'nickname' => $nickname,
                'message' => $message,
                'ip' => $ip
            ];
            file_put_contents($messagesFile, json_encode($messages));

            // 重定向到当前页面，避免表单重复提交
            header('Location: ' . $_SERVER['PHP_SELF']);
            exit;
        }
    }
}

function getMessageImageUrl($qq) {
    return "http://q1.qlogo.cn/g?b=qq&nk=$qq&s=100";
}

?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>留言板</title>
    <link href="/tailwind.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f0f8ff;
            color: #333;
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
            font-family: Arial, sans-serif;
        }
        .message-card {
            border: 1px solid #007bff;
            border-radius: 16px;
            padding: 16px;
            margin-bottom: 16px;
            display: flex;
            align-items: center;
            background-color: #007bff;
            color: #fff;
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.1);
            opacity: 0;
            animation: flyIn 0.8s ease-in-out forwards;
            position: relative;
            max-width: 100%;
            box-sizing: border-box;
        }
        .message-card img {
            border-radius: 50%;
            margin-right: 16px;
            width: 50px;
            height: 50px;
        }
        .message-card .content {
            flex: 1;
        }
        .message-card .delete-button {
            position: absolute;
            top: 10px;
            right: 10px;
            background: none;
            border: none;
            color: #b0b0b0; /* 初始灰色 */
            cursor: pointer;
            font-size: 16px; /* 较小的字体大小 */
            transition: color 0.3s;
        }
        .message-card .delete-button:hover {
            color: #808080; /* 悬停时深灰色 */
        }
        .form-container {
            background-color: #e3f2fd;
            padding: 20px;
            border-radius: 16px;
            margin-top: 32px;
            color: #333;
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.1);
            opacity: 0;
            animation: fadeIn 1s ease-in-out forwards;
        }
        .form-container input,
        .form-container textarea,
        .form-container button {
            width: 100%;
            margin-bottom: 16px;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 16px;
            box-sizing: border-box;
            outline: none;
        }
        .form-container input:focus,
        .form-container textarea:focus,
        .form-container button:focus {
            outline: none;
            box-shadow: 0 0 5px rgba(0, 123, 255, 0.5);
        }
        .form-container button {
            background-color: #007bff;
            color: #fff;
            cursor: pointer;
            transition: background-color 0.3s;
        }
        .form-container button:hover {
            background-color: #0056b3;
        }
        @keyframes flyIn {
            0% {
                transform: translateX(var(--translateX)) translateY(var(--translateY));
                opacity: 0;
            }
            100% {
                transform: translateX(0) translateY(0);
                opacity: 1;
            }
        }
        @keyframes fadeIn {
            from {
                opacity: 0;
            }
            to {
                opacity: 1;
            }
        }


        footer {
    position: relative; /* 更改为 relative 或 static */
    bottom: 0;
    left: 0;
    width: 100%;
    padding: 20px 0;
    text-align: center;
    color: #6c757d; /* 可选：设置文字颜色 */
}

.footer-content {
    font-size: 14px;
    color: #6c757d;
}

.footer-content a {
    color: #6c757d;
    text-decoration: none;
}

.footer-content a:hover {
    text-decoration: underline;
}


    </style>
</head>
<body>

    <div class="container mx-auto p-6">
        <h1 class="text-3xl font-bold text-center text-blue-600 mb-6">留言板</h1>

        <div id="messages" class="grid grid-cols-1 sm:grid-cols-3 lg:grid-cols-3 gap-4">
            <?php foreach ($messages as $index => $msg): ?>
                <div class="message-card" style="--translateX: <?= rand(-80, 80) ?>px; --translateY: <?= rand(-1000, 1000) ?>px; animation-delay: <?= $index * 0.1 ?>s;">
                    <img src="<?= htmlspecialchars(getMessageImageUrl($msg['qq'])) ?>" alt="Avatar">
                    <div class="content">
                        <strong><?= htmlspecialchars($msg['nickname']) ?></strong>
                        <p><?= htmlspecialchars($msg['message']) ?></p>
                    </div>
                    <?php if ($msg['ip'] == $_SERVER['REMOTE_ADDR']): ?>
                        <form method="post" style="display: inline;">
                            <button type="submit" name="delete" value="<?= htmlspecialchars($msg['id']) ?>" class="delete-button">✖</button>
                        </form>
                    <?php endif; ?>
                </div>
            <?php endforeach; ?>
        </div>

        <div class="form-container" id="form-container" style="animation-delay: <?= count($messages) * 0.1 ?>s;">
            <form method="post">
                <input type="text" name="qq" placeholder="QQ号" required>
                <input type="text" name="nickname" placeholder="昵称" required>
                <textarea name="message" rows="4" placeholder="输入留言内容" required></textarea>
                <button type="submit">添加留言</button>
            </form>
            <?php if (isset($errorMessage)): ?>
                <p class="text-center text-red-500 mt-4"><?= htmlspecialchars($errorMessage) ?></p>
            <?php endif; ?>
        </div>
    </div>

    <script>
        document.addEventListener("DOMContentLoaded", function() {
            const messages = document.querySelectorAll(".message-card");
            messages.forEach((msg, index) => {
                setTimeout(() => {
                    msg.style.opacity = '1';
                    msg.style.transform = 'translateX(0) translateY(0)';
                }, index * 300 + 500);
            });

            const formContainer = document.getElementById('form-container');
            if (formContainer) {
                setTimeout(() => {
                    formContainer.style.display = 'block';
                    formContainer.style.opacity = '1';
                }, messages.length * 300 + 500);
            }
        });
    </script>
    <footer> 
        <div class="footer-content"> 
            By <a href="http://oss.fuxsto.cn/" target="_blank">FurryBox Studio</a> 
          <br>Beta 2.2.0<br> 
          <script defer src="https://cn.vercount.one/js"></script><br> 
          本站总访问量 <span id="busuanzi_value_site_pv">加载中...</span> 次<br> 
本站总访客数 <span id="busuanzi_value_site_uv">加载中...</span> 人
        </div> 
    </footer>
</body>
</html>
